package com.example.project1;

public class Phone {
    private String name;
    private String number;

    public Phone(){

    }
    public Phone(String name, String number)
    {
        this.name = name;
        this.number = number;
    }

    public String getName() {
        return name;
    }
    public void setName(String name)
    {
        this.name = name;
    }
    public String getNum(String name){
        return number;
    }
    public void setNum(String number)
    {
        this.number=number;
    }
}

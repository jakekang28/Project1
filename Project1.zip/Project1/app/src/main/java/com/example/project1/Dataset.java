package com.example.project1;
import android.graphics.drawable.Drawable;

public class Dataset {
    String text;
    Drawable image;
}
